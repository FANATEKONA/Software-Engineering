import { describe, it, expect } from 'vitest';
import { filterRooms, getEquipmentOptions, matchRooms, parseAttendeeCount } from '@/lib/roomFilter';
import { ROOMS } from '@/data/demoData';

const ids = (rooms: { id: string }[]) => rooms.map((r) => r.id);

describe('F1 capacity filter', () => {
  it('excludes rooms whose capacity is below the attendee count', () => {
    expect(ids(filterRooms(ROOMS, { attendees: 9, equipment: [] }))).toEqual(['C-303']);
  });

  it('includes rooms whose capacity equals the attendee count', () => {
    expect(ids(filterRooms(ROOMS, { attendees: 8, equipment: [] }))).toEqual(['B-202', 'C-303']);
    expect(ids(filterRooms(ROOMS, { attendees: 4, equipment: [] }))).toEqual(['A-101', 'B-202', 'C-303', 'D-404']);
  });
});

describe('F2 equipment filter', () => {
  it('requires every selected equipment item', () => {
    expect(ids(filterRooms(ROOMS, { attendees: 1, equipment: ['Projector', 'Whiteboard'] }))).toEqual([
      'A-101',
      'D-404',
    ]);
    expect(ids(filterRooms(ROOMS, { attendees: 1, equipment: ['Computers', 'Projector'] }))).toEqual(['D-404']);
  });

  it('applies no restriction when no equipment is selected', () => {
    expect(ids(filterRooms(ROOMS, { attendees: 1, equipment: [] }))).toEqual(['A-101', 'B-202', 'C-303', 'D-404']);
  });

  it('lists each equipment option once, sorted', () => {
    expect(getEquipmentOptions(ROOMS)).toEqual(['Computers', 'Projector', 'Video Conferencing', 'Whiteboard']);
  });
});

describe('F4 empty result', () => {
  it('returns no rooms when no room satisfies the filters', () => {
    expect(matchRooms(ROOMS, { attendeesInput: '13', equipment: [] })).toEqual({
      attendeesValid: true,
      rooms: [],
    });
  });
});

describe('invalid attendee counts', () => {
  it.each(['', '0', '-1', '2.5', 'abc', ' 3'])('treats %j as invalid and returns no rooms', (input) => {
    expect(matchRooms(ROOMS, { attendeesInput: input, equipment: [] })).toEqual({
      attendeesValid: false,
      rooms: [],
    });
  });

  it('accepts a positive whole number', () => {
    expect(parseAttendeeCount('3')).toBe(3);
    expect(matchRooms(ROOMS, { attendeesInput: '3', equipment: [] }).attendeesValid).toBe(true);
  });
});
